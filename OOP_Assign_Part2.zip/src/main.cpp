#include "interface.h"

int main() {
    interface interface;
    interface.main_menu();

    return 0;
}
